<?php 
  include_once 'Navbar.php';
  $conn=mysqli_connect("localhost","root","","admin");
  
  $sql=mysqli_query($conn,"SELECT Pro_name,Sell_Price,image FROM product");
?>


<html>
<head>
   <title>Home Page</title>
   </head>

<body>
		   
			   
	   <form method="POST" action="">
	  
			 
			  <?php
			   
	       while($row=mysqli_fetch_assoc($sql)){
			   $pro_name=$row["Pro_name"];
			   $cost=$row["Sell_Price"];
			   $image=$row["image"];
			   $cart="<a href='CartDB.php?Pro_name={$pro_name}'><span class='material-symbols-outlined'>add_shopping_cart</span></a>";
			   $wish="<a href='WishlistDB.php?Pro_name={$pro_name}'><span class='material-symbols-outlined'>favorite</span></a>";
	         echo '<div class="container">
	 <a href=""><img src="'.$image.'" alt="image" width="200px" height="200px"></a><br><br>
	 <div class="text">';
	 echo $wish;
	  echo '<h2>'.$pro_name.'</h2>
	          <h3>$'.$cost.'</h3>';
	echo $cart;
			 echo '</div>
			  </div>';
			  }
			  
			 
			  ?>
	  </form>
	 
	 
	
</body>
</html>
