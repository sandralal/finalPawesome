<html>
<head>
<title>File Upload</title>
<link rel="stylesheet" href="Homepage.css">
<link rel="stylesheet" href="Add_stock.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
 <body>
 
 
    <div class="nav">

    <h3>ECO SHOP</h3>
	
	  <div class="navbar">
	   
	   <div class="tooltip"> <a href="">New<span class="tooltiptext">F</span></a> </div> 
	   <div class="tooltip"> <a href="">New<span class="tooltiptext">P</span></a> </div> 
	   <div class="tooltip"> <a href="">New<span class="tooltiptext">D</span></a> </div>
	                         <a href=""><span class="material-symbols-outlined">search</span></a>
	                         <a href="http://localhost/Practice%20Prj/Wishlist.php"><span class="material-symbols-outlined">favorite</span></a>
	     </div>
	  </div>
   <form method="POST" action="Add_stockDB.php" enctype="multipart/form-data">
   
           <label>Title:</label><input type="text" name="title"/> <br><br>
		   <label>File Upload:</label><input type="file" name="file"/><br><br>
		   <label>Cost Price:</label><input type="number" name="cost"/><br><br>
		    <label>Sell Price:</label><input type="number" name="sell"/><br><br>
		   <label>Count:</label><input type="number" name="count"/><br><br>
		   <input type="submit" name="submit"/>
		   </form>
	</body>
	</html>