<?php

    $conn=mysqli_connect("localhost","root","","admin");
	
	if(isset($_POST["submit"])){
		$ptitle=$_POST["title"];
		$pcost=$_POST["cost"];
		$psell=$_POST["sell"];
		$pcount=$_POST["count"];
		$pimg=$_FILES["file"]["name"];
		$sql="INSERT INTO product VALUES('$ptitle','$pcost','$psell','$pimg','$pcount')";
		
		if(mysqli_query($conn,$sql)){
			echo "Success";
			
	}
	else{
		echo "failed";
	}
	}
	?>